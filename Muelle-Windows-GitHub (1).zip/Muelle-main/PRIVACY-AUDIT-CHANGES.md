# Muelle — modifications de confidentialité

Cette archive est une variante source modifiée de Muelle, préparée à partir de l'archive fournie.

## Changements appliqués

- Désactivation complète de l'intégration des quotas IA : le dock ne lit plus les fichiers d'authentification Claude, Codex, OpenCode, Gemini ou Antigravity.
- Suppression des requêtes réseau de cette intégration et de sa dépendance `reqwest` dans le crate du dock.
- Désactivation de la surveillance des processus des clients IA liée à cette fonction.
- Suppression du lancement périodique de l'installateur de mises à jour en arrière-plan.
- Les Réglages ne contactent plus GitHub à leur ouverture. Une recherche de mise à jour reste possible manuellement avec le bouton prévu à cet effet.
- Désactivation par défaut des options historiques de vérification/mise à jour et de quotas IA pour les nouvelles configurations.
- Conservation du démarrage automatique Windows et du mécanisme de restauration de la barre des tâches.

## Limites de vérification

- Aucun exécutable, script d'installation ou dépendance n'a été lancé.
- Il s'agit d'une modification du code source, pas d'un binaire compilé.
- La compilation et les tests Windows n'ont pas été exécutés dans cet environnement. Il faut compiler et tester le projet sur Windows avant toute installation.
- Les fonctionnalités de quotas IA ne sont plus disponibles dans cette variante.
- La vérification et l'installation manuelles d'une mise à jour continuent de contacter GitHub uniquement lorsque l'utilisateur les déclenche depuis Réglages.

## Éléments observés dans l'archive d'origine

Le module `apps/dock/src/usage.rs` lisait des fichiers d'authentification locaux puis utilisait les jetons pour interroger les services des fournisseurs IA afin de récupérer les quotas. Le module Antigravity acceptait également des certificats TLS invalides pour contacter un service local. Cela ne prouve pas une exfiltration vers le développeur, mais cette surface d'accès n'était pas nécessaire au dock de base.

Les fichiers de scripts de packaging et les workflows GitHub sont conservés dans cette archive. Ils n'ont pas été exécutés.
