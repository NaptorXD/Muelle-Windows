//! Platform-independent dock logic that can be tested without Windows.

pub mod bounce;
pub mod genie;
pub mod layout;
pub mod magnify;
pub mod roster;
pub mod spring;
