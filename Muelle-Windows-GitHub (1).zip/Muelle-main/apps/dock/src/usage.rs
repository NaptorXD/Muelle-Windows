//! Quota integration intentionally disabled in this privacy-focused build.
//!
//! This module keeps the UI-facing types so the rest of the dock can compile,
//! but it does not inspect local authentication files, enumerate AI client processes,
//! or make network requests.

use chrono::{DateTime, Utc};
use muelle_shell::icons::IconImage;
use serde::{Deserialize, Serialize};
use std::time::SystemTime;

#[derive(Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum State {
    Loading,
    Ready,
    SignIn,
    Unavailable,
}

#[derive(Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Window {
    #[serde(default)]
    pub label: Option<String>,
    pub minutes: i64,
    pub used_percent: u8,
    pub resets_at: Option<DateTime<Utc>>,
}

impl Window {
    pub fn title(&self) -> String {
        if let Some(label) = &self.label {
            label.clone()
        } else if self.minutes >= 25 * 24 * 60 {
            "30 d".to_owned()
        } else if self.minutes >= 2 * 24 * 60 {
            "7 d".to_owned()
        } else if self.minutes >= 60 {
            format!("{} h", self.minutes / 60)
        } else {
            format!("{} min", self.minutes)
        }
    }

    pub fn reset_text(&self) -> Option<String> {
        self.resets_at
            .map(|time| time.with_timezone(&chrono::Local).format("%d/%m %H:%M").to_string())
    }
}

#[derive(Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ProviderUsage {
    pub state: State,
    pub windows: Vec<Window>,
    pub fetched_at: Option<SystemTime>,
}

impl Default for ProviderUsage {
    fn default() -> Self {
        Self {
            state: State::Loading,
            windows: Vec::new(),
            fetched_at: None,
        }
    }
}

impl ProviderUsage {
    pub fn main_window(&self) -> Option<&Window> {
        self.windows.first()
    }

    pub fn age_minutes(&self) -> Option<u64> {
        Some(self.fetched_at?.elapsed().ok()?.as_secs() / 60)
    }
}

#[derive(Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct Snapshot {
    pub providers: [ProviderUsage; Provider::COUNT],
}

impl Snapshot {
    pub fn get(&self, provider: Provider) -> &ProviderUsage {
        &self.providers[provider as usize]
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
#[repr(usize)]
pub enum Provider {
    Claude,
    Codex,
    OpenCode,
    Gemini,
}

impl Provider {
    pub const COUNT: usize = 4;
    pub const ALL: [Self; Self::COUNT] = [Self::Claude, Self::Codex, Self::OpenCode, Self::Gemini];

    pub fn name(self) -> &'static str {
        match self {
            Self::Claude => "Claude",
            Self::Codex => "Codex",
            Self::OpenCode => "OpenCode",
            Self::Gemini => "Gemini",
        }
    }
}

#[derive(Clone, Copy, Default, PartialEq, Eq)]
pub struct ActiveProviders(pub [bool; Provider::COUNT]);

impl ActiveProviders {
    pub fn any(self) -> bool {
        self.0.iter().any(|active| *active)
    }

    pub fn count(self) -> usize {
        self.0.iter().filter(|active| **active).count()
    }

    pub fn has(self, provider: Provider) -> bool {
        self.0[provider as usize]
    }
}

/// No AI client process inspection is performed.
pub fn active_providers() -> ActiveProviders {
    ActiveProviders::default()
}

/// Quota-provider logos are not loaded in this build.
pub fn logo(_provider: Provider) -> Option<&'static IconImage> {
    None
}

pub struct Monitor;

impl Monitor {
    pub fn new(_hwnd: isize, _changed_message: u32) -> Self {
        Self
    }

    pub fn snapshot(&self) -> Snapshot {
        Snapshot::default()
    }

    pub fn is_refreshing(&self) -> bool {
        false
    }

    pub fn mark_inactive(&mut self) {}

    /// Intentionally does nothing: quota monitoring is disabled.
    pub fn refresh(&mut self, _force: bool) {}
}

/// Kept for command-line compatibility; emits an empty snapshot only.
pub fn worker_main() -> anyhow::Result<()> {
    serde_json::to_writer(std::io::stdout().lock(), &Snapshot::default())?;
    Ok(())
}
