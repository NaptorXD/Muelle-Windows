//! Muelle settings: a separate process that exists only while its window is
//! open. It edits the configuration file and tells the dock to reload it.
//!
//! Update checks and installation are only started manually from its window.

#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::{env, io, path::PathBuf, process::Command, sync::Mutex};

use muelle_config::Config;
use muelle_shell::{autostart, dock_link, launcher};
use serde::Serialize;
use tauri::{AppHandle, Emitter, Manager, State, WebviewWindowBuilder};
use tauri_plugin_updater::{Update, UpdaterExt};

/// The dock is installed next to this app.
fn dock_exe() -> io::Result<PathBuf> {
    Ok(env::current_exe()?.with_file_name("muelle.exe"))
}

#[tauri::command]
fn get_config() -> Config {
    muelle_config::load(&muelle_config::default_path())
        .ok()
        .flatten()
        .unwrap_or_default()
}

/// The defaults live in `muelle-config`; the window asks for them to reset.
#[tauri::command]
fn default_config() -> Config {
    Config::default()
}

#[tauri::command]
async fn set_config(patch: serde_json::Map<String, serde_json::Value>) -> Result<Config, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let config = muelle_config::update_preferences(&muelle_config::default_path(), patch)
            .map_err(|error| error.to_string())?;
        dock_link::notify_config_changed();
        Ok(config)
    })
    .await
    .map_err(|error| error.to_string())?
}

/// Windows' own animation setting, which the genie follows: off, the
/// genie does not play, and the window says so.
#[tauri::command]
fn windows_animations() -> bool {
    muelle_shell::system::animations_enabled()
}

/// The page of Windows Settings with that switch: "Animation effects" on
/// Windows 11, "Show animations in Windows" on Windows 10.
#[tauri::command]
fn open_animation_settings() -> Result<(), String> {
    let page = if muelle_shell::system::is_windows_11() {
        "ms-settings:easeofaccess-visualeffects"
    } else {
        "ms-settings:easeofaccess-display"
    };
    launcher::open(page).map_err(|error| error.to_string())
}

/// Asks for the folder the dock shows as a menu, opened at `current`;
/// `None` if the user cancels. The dialog runs on its own thread, so the
/// window keeps drawing behind it.
#[tauri::command]
async fn pick_folder(
    window: tauri::WebviewWindow,
    current: Option<String>,
) -> Result<Option<String>, String> {
    let owner = window
        .hwnd()
        .map(|hwnd| hwnd.0 as isize)
        .unwrap_or_default();
    tauri::async_runtime::spawn_blocking(move || {
        muelle_shell::folder::pick(owner, current.as_deref())
    })
    .await
    .map_err(|error| error.to_string())
}

#[tauri::command]
async fn get_autostart() -> Result<bool, String> {
    let dock = dock_exe().map_err(|error| error.to_string())?;
    tauri::async_runtime::spawn_blocking(move || {
        Ok(
            autostart::enabled_for(&dock.to_string_lossy()).unwrap_or_else(|error| {
                muelle_shell::log::line(&format!(
                    "no se pudo consultar el inicio automático: {error}"
                ));
                // The cached choice still lets Settings open if the scheduler
                // service is unavailable. An explicit change reports its error.
                autostart::is_enabled()
            }),
        )
    })
    .await
    .map_err(|error| error.to_string())?
}

#[tauri::command]
async fn set_autostart(enabled: bool) -> Result<(), String> {
    let dock = dock_exe().map_err(|error| error.to_string())?;
    let target = enabled.then(|| dock.to_string_lossy().into_owned());
    tauri::async_runtime::spawn_blocking(move || {
        autostart::set(target.as_deref()).map_err(|error| error.to_string())
    })
    .await
    .map_err(|error| error.to_string())?
}

/// The update found by the last check, kept until the user installs it.
#[derive(Default)]
struct PendingUpdate(Mutex<Option<Update>>);

/// Asks GitHub Releases for a newer version; returns it, if any. Only runs
/// while Settings is open: the dock itself never touches the network.
#[tauri::command]
async fn check_update(
    app: tauri::AppHandle,
    pending: State<'_, PendingUpdate>,
) -> Result<Option<UpdateInfo>, String> {
    let update = app
        .updater()
        .map_err(|error| error.to_string())?
        .check()
        .await
        .map_err(|error| error.to_string())?;
    let info = update.as_ref().map(|update| UpdateInfo {
        version: update.version.clone(),
        notes: update.body.clone().filter(|notes| is_release_page(notes)),
    });
    *pending.0.lock().map_err(|error| error.to_string())? = update;
    Ok(info)
}

/// What the window shows about an available update.
#[derive(Serialize)]
struct UpdateInfo {
    version: String,
    /// The release page, when the manifest points at one.
    notes: Option<String>,
}

/// Download progress, sent to the window as `update-progress`.
#[derive(Clone, Serialize)]
struct Progress {
    downloaded: u64,
    total: Option<u64>,
}

const RELEASES: &str = "https://github.com/crafter-station/Muelle/releases/";

/// The update manifest is not signed (only the installer is), so the only
/// link it may open is a release page of this repository.
fn is_release_page(url: &str) -> bool {
    url.starts_with(RELEASES) && !url.contains(char::is_whitespace)
}

#[tauri::command]
fn open_release_notes(url: String) -> Result<(), String> {
    if !is_release_page(&url) {
        return Err("enlace no permitido".into());
    }
    launcher::open(&url).map_err(|error| error.to_string())
}

/// Downloads the signed installer and runs it; the installer stops the dock,
/// replaces both apps and starts the dock again. This process exits.
#[tauri::command]
async fn install_update(
    app: tauri::AppHandle,
    pending: State<'_, PendingUpdate>,
) -> Result<(), String> {
    // Cloned, not taken: if the download fails the user can try again.
    let update = pending
        .0
        .lock()
        .map_err(|error| error.to_string())?
        .clone()
        .ok_or("no hay ninguna actualización pendiente")?;
    let mut downloaded = 0u64;
    update
        .download_and_install(
            |chunk, total| {
                downloaded += chunk as u64;
                let _ = app.emit("update-progress", Progress { downloaded, total });
            },
            || {},
        )
        .await
        .map_err(|error| error.to_string())
}

/// Opens the Settings window, or brings it forward if it is open.
fn show_window(app: &AppHandle) {
    if let Some(window) = app.get_webview_window("main") {
        let _ = window.unminimize();
        let _ = window.show();
        let _ = window.set_focus();
        return;
    }
    let Some(config) = app.config().app.windows.first() else {
        return;
    };
    if let Err(error) =
        WebviewWindowBuilder::from_config(app, config).and_then(|window| window.build())
    {
        eprintln!("muelle-settings: {error}");
    }
}

fn main() {
    muelle_config::migrate_legacy_folder();
    // The Start menu entry opens this app: it also brings back a dock the user quit.
    if !dock_link::is_running()
        && let Err(error) = dock_exe().and_then(|dock| Command::new(dock).spawn())
    {
        eprintln!("muelle-settings: no se pudo abrir el dock: {error}");
    }
    let result = tauri::Builder::default()
        // First, so a second launch exits before doing anything else.
        .plugin(tauri_plugin_single_instance::init(|app, _args, _| {
            show_window(app);
        }))
        .plugin(tauri_plugin_updater::Builder::new().build())
        .manage(PendingUpdate::default())
        .setup(move |app| {
            show_window(app.handle());
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            get_config,
            default_config,
            set_config,
            get_autostart,
            set_autostart,
            windows_animations,
            open_animation_settings,
            pick_folder,
            check_update,
            install_update,
            open_release_notes
        ])
        .run(tauri::generate_context!());
    if let Err(error) = result {
        eprintln!("muelle-settings: {error}");
    }
}
