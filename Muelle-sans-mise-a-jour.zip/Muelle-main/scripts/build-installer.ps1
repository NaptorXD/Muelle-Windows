# Builds the one-step installer: Muelle_<version>_x64-setup.exe.
# Usage: scripts/build-installer.ps1   (from any folder)
#

# Not 'Stop': Windows PowerShell turns cargo's progress on stderr into errors;
# each native step checks $LASTEXITCODE instead.
$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent $PSScriptRoot
Push-Location $root
try {
    $target = (cargo metadata --format-version 1 --no-deps | ConvertFrom-Json).target_directory
    $triple = 'x86_64-pc-windows-msvc'

    cargo build --release -p muelle
    if ($LASTEXITCODE) { throw 'cargo build muelle failed' }

    # Tauri bundles sidecars from src-tauri/binaries/<name>-<target triple>.exe.
    $binaries = Join-Path $root 'apps/settings/src-tauri/binaries'
    New-Item -ItemType Directory -Force $binaries -ErrorAction Stop | Out-Null
    Copy-Item (Join-Path $target 'release/muelle.exe') (Join-Path $binaries "muelle-$triple.exe") -Force -ErrorAction Stop

    $configs = @('--config', 'src-tauri/tauri.bundle.conf.json')

    Push-Location (Join-Path $root 'apps/settings')
    try {
        pnpm tauri build @configs
        if ($LASTEXITCODE) { throw 'tauri build failed' }
    } finally { Pop-Location }

    Get-ChildItem (Join-Path $target 'release/bundle/nsis/*-setup.exe*') |
        Select-Object FullName, @{ n = 'MB'; e = { [math]::Round($_.Length / 1MB, 2) } }
} finally { Pop-Location }
