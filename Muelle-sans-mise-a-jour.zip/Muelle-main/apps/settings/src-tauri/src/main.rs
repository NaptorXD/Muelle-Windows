//! Muelle settings: a separate process that exists only while its window is
//! open. It edits the configuration file and tells the dock to reload it.

#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::{env, io, path::PathBuf, process::Command};

use muelle_config::Config;
use muelle_shell::{autostart, dock_link, launcher};
use tauri::{AppHandle, Manager, WebviewWindowBuilder};

/// The dock is installed next to this app.
fn dock_exe() -> io::Result<PathBuf> {
    Ok(env::current_exe()?.with_file_name("muelle.exe"))
}

#[tauri::command]
fn get_config() -> Config {
    muelle_config::load(&muelle_config::default_path())
        .ok()
        .flatten()
        .unwrap_or_default()
}

/// The defaults live in `muelle-config`; the window asks for them to reset.
#[tauri::command]
fn default_config() -> Config {
    Config::default()
}

#[tauri::command]
async fn set_config(patch: serde_json::Map<String, serde_json::Value>) -> Result<Config, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let config = muelle_config::update_preferences(&muelle_config::default_path(), patch)
            .map_err(|error| error.to_string())?;
        dock_link::notify_config_changed();
        Ok(config)
    })
    .await
    .map_err(|error| error.to_string())?
}

/// Windows' own animation setting, which the genie follows: off, the
/// genie does not play, and the window says so.
#[tauri::command]
fn windows_animations() -> bool {
    muelle_shell::system::animations_enabled()
}

/// The page of Windows Settings with that switch: "Animation effects" on
/// Windows 11, "Show animations in Windows" on Windows 10.
#[tauri::command]
fn open_animation_settings() -> Result<(), String> {
    let page = if muelle_shell::system::is_windows_11() {
        "ms-settings:easeofaccess-visualeffects"
    } else {
        "ms-settings:easeofaccess-display"
    };
    launcher::open(page).map_err(|error| error.to_string())
}

/// Asks for the folder the dock shows as a menu, opened at `current`;
/// `None` if the user cancels. The dialog runs on its own thread, so the
/// window keeps drawing behind it.
#[tauri::command]
async fn pick_folder(
    window: tauri::WebviewWindow,
    current: Option<String>,
) -> Result<Option<String>, String> {
    let owner = window
        .hwnd()
        .map(|hwnd| hwnd.0 as isize)
        .unwrap_or_default();
    tauri::async_runtime::spawn_blocking(move || {
        muelle_shell::folder::pick(owner, current.as_deref())
    })
    .await
    .map_err(|error| error.to_string())
}

#[tauri::command]
async fn get_autostart() -> Result<bool, String> {
    let dock = dock_exe().map_err(|error| error.to_string())?;
    tauri::async_runtime::spawn_blocking(move || {
        Ok(
            autostart::enabled_for(&dock.to_string_lossy()).unwrap_or_else(|error| {
                muelle_shell::log::line(&format!(
                    "no se pudo consultar el inicio automático: {error}"
                ));
                // The cached choice still lets Settings open if the scheduler
                // service is unavailable. An explicit change reports its error.
                autostart::is_enabled()
            }),
        )
    })
    .await
    .map_err(|error| error.to_string())?
}

#[tauri::command]
async fn set_autostart(enabled: bool) -> Result<(), String> {
    let dock = dock_exe().map_err(|error| error.to_string())?;
    let target = enabled.then(|| dock.to_string_lossy().into_owned());
    tauri::async_runtime::spawn_blocking(move || {
        autostart::set(target.as_deref()).map_err(|error| error.to_string())
    })
    .await
    .map_err(|error| error.to_string())?
}

/// Opens the Settings window, or brings it forward if it is open.
fn show_window(app: &AppHandle) {
    if let Some(window) = app.get_webview_window("main") {
        let _ = window.unminimize();
        let _ = window.show();
        let _ = window.set_focus();
        return;
    }
    let Some(config) = app.config().app.windows.first() else {
        return;
    };
    if let Err(error) =
        WebviewWindowBuilder::from_config(app, config).and_then(|window| window.build())
    {
        eprintln!("muelle-settings: {error}");
    }
}

fn main() {
    muelle_config::migrate_legacy_folder();
    // The Start menu entry opens this app: it also brings back a dock the user quit.
    if !dock_link::is_running()
        && let Err(error) = dock_exe().and_then(|dock| Command::new(dock).spawn())
    {
        eprintln!("muelle-settings: no se pudo abrir el dock: {error}");
    }
    let result = tauri::Builder::default()
        // First, so a second launch exits before doing anything else.
        .plugin(tauri_plugin_single_instance::init(|app, _args, _| {
            show_window(app);
        }))
        .setup(move |app| {
            show_window(app.handle());
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            get_config,
            default_config,
            set_config,
            get_autostart,
            set_autostart,
            windows_animations,
            open_animation_settings,
            pick_folder
        ])
        .run(tauri::generate_context!());
    if let Err(error) = result {
        eprintln!("muelle-settings: {error}");
    }
}
