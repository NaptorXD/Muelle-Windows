import { getCurrentWindow } from "@tauri-apps/api/window";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  type Config,
  type Language,
  ICON_SIZE,
  MAX_MAGNIFIED_SIZE,
  defaultConfig,
  getAutostart,
  openAnimationSettings,
  windowsAnimations,
  loadConfig,
  pickFolder,
  saveConfig,
  setAutostart,
} from "./config";
import { Card, Row, Segmented, Slider, SubRow, Toggle } from "./controls";
import { type SectionId, SectionIcon } from "./icons";
import en from "./i18n/en.json";
import es from "./i18n/es.json";
import fr from "./i18n/fr.json";

type Texts = typeof es;

/** Dragging a slider saves at most this often; the dock redraws on each save. */
const SAVE_DELAY_MS = 60;
/** How long the reset button stays armed after the first click. */
const RESET_CONFIRM_MS = 4000;

const TEXTS: Record<Exclude<Language, "auto">, Texts> = { es, en, fr };

function textsFor(language: Language): Texts {
  if (language !== "auto") {
    return TEXTS[language];
  }
  // Follow the Windows display language, English when there is no text in it.
  const windows = navigator.language.toLowerCase().slice(0, 2);
  return windows === "es" || windows === "fr" ? TEXTS[windows] : en;
}

export function App() {
  const [config, setConfig] = useState<Config | null>(null);
  const [autostart, setAutostartState] = useState(false);
  // Assumed on until asked, so the notice never flashes on a normal PC.
  const [animations, setAnimations] = useState(true);
  useEffect(() => {
    const check = () => {
      windowsAnimations()
        .then(setAnimations)
        .catch(() => {});
    };
    check();
    // Back from Windows Settings after turning them on: the notice goes.
    window.addEventListener("focus", check);
    return () => window.removeEventListener("focus", check);
  }, []);
  const [section, setSection] = useState<SectionId>("dock");
  const [failed, setFailed] = useState(false);
  const [confirmingReset, setConfirmingReset] = useState(false);
  const pending = useRef<Partial<Config> | null>(null);
  const writes = useRef(Promise.resolve());
  const timer = useRef<number | undefined>(undefined);
  const resetTimer = useRef<number | undefined>(undefined);

  const flushSettings = useCallback(() => {
    window.clearTimeout(timer.current);
    const latest = pending.current;
    pending.current = null;
    if (latest) {
      writes.current = writes.current
        .then(() => saveConfig(latest))
        .then(() => setFailed(false))
        .catch(() => setFailed(true));
    }
    return writes.current;
  }, []);

  useEffect(() => {
    let alive = true;
    Promise.all([loadConfig(), getAutostart()])
      .then(([loaded, starts]) => {
        if (!alive) return;
        setConfig(loaded);
        setAutostartState(starts);
      })
      .catch(() => alive && setFailed(true));
    let closing = false;
    const close = getCurrentWindow().onCloseRequested(async (event) => {
      if (!alive || closing) {
        event.preventDefault();
        return;
      }
      closing = true;
      // A change can be buffered or queued while an earlier write finishes.
      let drained: Promise<void>;
      do {
        drained = flushSettings();
        await drained;
      } while (pending.current || writes.current !== drained);
    });
    return () => {
      alive = false;
      window.clearTimeout(timer.current);
      window.clearTimeout(resetTimer.current);
      close.then((unlisten) => unlisten()).catch(() => {});
    };
  }, [flushSettings]);

  // Shows the change at once and saves the latest value shortly after, so a
  // slider drag does not write the file on every pixel.
  const update = useCallback((patch: Partial<Config>) => {
    setConfig((current) => {
      if (!current) return current;
      const next = { ...current, ...patch };
      if (next.magnifiedSize < next.iconSize) next.magnifiedSize = next.iconSize;
      return next;
    });
    pending.current = { ...pending.current, ...patch };
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => void flushSettings(), SAVE_DELAY_MS);
  }, [flushSettings]);

  const changeAutostart = useCallback((enabled: boolean) => {
    setAutostartState(enabled);
    setAutostart(enabled).catch(() => {
      setAutostartState(!enabled);
      setFailed(true);
    });
  }, []);

  // Two clicks: the first arms the button, the second resets. Pinned and
  // recent apps stay; they belong to the user, not to the settings.
  const reset = useCallback(() => {
    if (!confirmingReset) {
      setConfirmingReset(true);
      resetTimer.current = window.setTimeout(() => setConfirmingReset(false), RESET_CONFIRM_MS);
      return;
    }
    setConfirmingReset(false);
    defaultConfig()
      .then(({ pinned: _pinned, recent: _recent, shortcutsFolder: _folder, ...defaults }) =>
        update(defaults),
      )
      .catch(() => setFailed(true));
  }, [confirmingReset, update]);

  if (!config) return <div className="window" />;
  const t = textsFor(config.language);
  const chooseFolder = () => {
    pickFolder(config.shortcutsFolder)
      .then((folder) => folder && update({ shortcutsFolder: folder }))
      .catch(() => setFailed(true));
  };
  const appWindow = getCurrentWindow();

  return (
    <div className="window">
      <aside className="sidebar" data-tauri-drag-region>
        <div className="traffic">
          <button
            type="button"
            className="light light-close"
            aria-label={t.close}
            onClick={() => appWindow.close()}
          />
          <button
            type="button"
            className="light light-minimize"
            aria-label={t.minimize}
            onClick={() => appWindow.minimize()}
          />
          <button
            type="button"
            className="light light-zoom"
            aria-label={t.zoom}
            onClick={() => appWindow.toggleMaximize()}
          />
        </div>
        <nav>
          {SECTIONS.map((id) => (
            <NavItem
              key={id}
              section={id}
              active={section === id}
              onSelect={() => setSection(id)}
            >
              {sectionTitle(t, id)}
            </NavItem>
          ))}
        </nav>
      </aside>

      <main className="content">
        <header className="content-title" data-tauri-drag-region>
          {sectionTitle(t, section)}
        </header>
        <div className="content-body">
          {section === "dock" ? (
            <>
              <Card>
                <Row label={t.size}>
                  <Slider
                    label={t.size}
                    value={config.iconSize}
                    min={ICON_SIZE.min}
                    max={ICON_SIZE.max}
                    before={t.small}
                    after={t.large}
                    onChange={(iconSize) => update({ iconSize })}
                  />
                </Row>
                <Row label={t.magnification} hint={t.magnificationHint}>
                  <Toggle
                    label={t.magnification}
                    checked={config.magnification}
                    onChange={(magnification) => update({ magnification })}
                  />
                </Row>
                <SubRow label={t.magnifiedSize} open={config.magnification}>
                  <Slider
                    label={t.magnifiedSize}
                    value={config.magnifiedSize}
                    min={config.iconSize}
                    max={MAX_MAGNIFIED_SIZE}
                    before={t.small}
                    after={t.large}
                    onChange={(magnifiedSize) => update({ magnifiedSize })}
                  />
                </SubRow>
              </Card>
              <Card title={t.groupBehavior}>
                <Row label={t.autoHide} hint={t.autoHideHint}>
                  <Toggle
                    label={t.autoHide}
                    checked={config.autoHide}
                    onChange={(autoHide) => update({ autoHide })}
                  />
                </Row>
                <Row label={t.bounceOnOpen}>
                  <Toggle
                    label={t.bounceOnOpen}
                    checked={config.bounceOnOpen}
                    onChange={(bounceOnOpen) => update({ bounceOnOpen })}
                  />
                </Row>
                <Row label={t.mascot} hint={t.mascotHint}>
                  <Toggle
                    label={t.mascot}
                    checked={config.mascot}
                    onChange={(mascot) => update({ mascot })}
                  />
                </Row>
                <Row label={t.showIndicators}>
                  <Toggle
                    label={t.showIndicators}
                    checked={config.showIndicators}
                    onChange={(showIndicators) => update({ showIndicators })}
                  />
                </Row>
                <Row label={t.showRecents} hint={t.showRecentsHint}>
                  <Toggle
                    label={t.showRecents}
                    checked={config.showRecents}
                    onChange={(showRecents) => update({ showRecents })}
                  />
                </Row>
              </Card>
              <Card>
                <Row label={t.shortcutsFolder} hint={config.shortcutsFolder ?? t.shortcutsFolderHint}>
                  <div className="push-group">
                    {config.shortcutsFolder ? (
                      <button type="button" className="push" onClick={() => update({ shortcutsFolder: null })}>
                        {t.shortcutsFolderRemove}
                      </button>
                    ) : null}
                    <button type="button" className="push" onClick={chooseFolder}>
                      {t.shortcutsFolderChoose}
                    </button>
                  </div>
                </Row>
              </Card>
            </>
          ) : section === "windows" ? (
            <>
              <Card title={t.groupMinimize}>
                <Row label={t.genie} hint={t.genieHint}>
                  <Toggle
                    label={t.genie}
                    checked={config.genie}
                    onChange={(genie) => update({ genie })}
                  />
                </Row>
                <SubRow label={t.genieOff} hint={t.genieOffHint} open={config.genie && !animations}>
                  <button type="button" className="push" onClick={() => void openAnimationSettings()}>
                    {t.genieOffAction}
                  </button>
                </SubRow>
                <Row label={t.showMinimized} hint={t.showMinimizedHint}>
                  <Toggle
                    label={t.showMinimized}
                    checked={config.showMinimized}
                    onChange={(showMinimized) => update({ showMinimized })}
                  />
                </Row>
              </Card>
            </>
          ) : section === "menubar" ? (
            <Card>
              <Row label={t.menuBarShow} hint={t.menuBarHint}>
                <Toggle
                  label={t.menuBarShow}
                  checked={config.menuBar}
                  onChange={(menuBar) => update({ menuBar })}
                />
              </Row>
              <SubRow label={t.menuBarAutoHide} hint={t.menuBarAutoHideHint} open={config.menuBar}>
                <Toggle
                  label={t.menuBarAutoHide}
                  checked={config.menuBarAutoHide}
                  onChange={(menuBarAutoHide) => update({ menuBarAutoHide })}
                />
              </SubRow>
              <SubRow label={t.aiUsage} hint={t.aiUsageHint} open={config.menuBar}>
                <Toggle
                  label={t.aiUsage}
                  checked={config.aiUsage}
                  onChange={(aiUsage) => update({ aiUsage })}
                />
              </SubRow>
              <SubRow label={t.accessoryBattery} hint={t.accessoryBatteryHint} open={config.menuBar}>
                <Toggle
                  label={t.accessoryBattery}
                  checked={config.accessoryBattery}
                  onChange={(accessoryBattery) => update({ accessoryBattery })}
                />
              </SubRow>
            </Card>
          ) : (
            <>
              <Card>
                <Row label={t.autostart}>
                  <Toggle label={t.autostart} checked={autostart} onChange={changeAutostart} />
                </Row>
                <Row label={t.language}>
                  <Segmented<Language>
                    label={t.language}
                    value={config.language}
                    options={[
                      { value: "auto", label: t.languageAuto },
                      { value: "es", label: "Español" },
                      { value: "en", label: "English" },
                      { value: "fr", label: "Français" },
                    ]}
                    onChange={(language) => update({ language })}
                  />
                </Row>
              </Card>
              <Card>
                <Row label={t.reset} hint={confirmingReset ? t.resetConfirmHint : t.resetHint}>
                  <button
                    type="button"
                    className={confirmingReset ? "push push-danger" : "push"}
                    onClick={reset}
                  >
                    {confirmingReset ? t.resetConfirm : t.resetButton}
                  </button>
                </Row>
              </Card>
            </>
          )}
          {failed ? (
            <p className="error" role="alert">
              {t.saveError}
            </p>
          ) : null}
        </div>
      </main>
    </div>
  );
}

const SECTIONS: readonly SectionId[] = ["dock", "windows", "menubar", "system"];

function sectionTitle(t: Texts, section: SectionId): string {
  switch (section) {
    case "dock":
      return t.dock;
    case "windows":
      return t.windows;
    case "menubar":
      return t.menuBar;
    case "system":
      return t.system;
  }
}

interface NavItemProps {
  section: SectionId;
  active: boolean;
  onSelect: () => void;
  children: string;
}

function NavItem({ section, active, onSelect, children }: NavItemProps) {
  return (
    <button
      type="button"
      className="nav-item"
      aria-current={active ? "page" : undefined}
      onClick={onSelect}
    >
      <SectionIcon section={section} />
      {children}
    </button>
  );
}
